<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('page-title', 'Projects'); ?>
    <?php $__env->startSection('page-link', 'projects - index'); ?>
     <?php $__env->slot('title', null, []); ?> Projects <?php $__env->endSlot(); ?>

    <div class="max-w-7xl mx-auto">                
        
        <div class="bg-white rounded-3xl shadow-sm p-6 mb-6">
            <div class="flex flex-col md:flex-row gap-4 items-center justify-between">                            
                <div class="relative flex-1 max-w-md">
                    <input type="text" 
                           placeholder="Cari Project..." 
                           class="w-full bg-gray-100 border border-transparent focus:border-gray-300 rounded-2xl py-3 px-5 pl-12 text-sm focus:outline-none">
                    <i class="fas fa-search absolute left-5 top-3.5 text-gray-400"></i>
                </div>
                <div class="mt-4 md:mt-0">
                    <a href="<?php echo e(route('projects.form')); ?>" 
                    class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-2xl font-medium flex items-center gap-2 transition">
                        <i class="fas fa-plus"></i>
                        Buat Project
                    </a>
                </div>
            </div>            
            <div class="mt-6 overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="border-b border-gray-200 text-left text-sm text-gray-500">
                            <th class="pb-4 w-12">#</th>
                            <th class="pb-4">CODE</th>
                            <th class="pb-4">PROJECT</th>
                            <th class="pb-4">DEADLINE</th>
                            <th class="pb-4 text-center">AKSI</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 text-sm"> 
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($index % 2 == 0 ? 'bg-gray-50' : 'bg-white'); ?> hover:bg-gray-100 transition">
                                <td class="py-5 font-medium text-gray-400">
                                    <?php echo e(($projects->currentPage() - 1) * $projects->perPage() + $loop->iteration); ?>

                                </td>
                                <td class="py-5 font-medium"><?php echo e($project->code ?? '-'); ?></td>
                                <td class="py-5 text-gray-600"><?php echo e($project->name ?? '-'); ?></td>
                                <td class="py-5 text-gray-600"><?php echo e($project->ended_at->format('d M Y') ?? '-'); ?></td>
                                <td class="py-5 text-center">
                                    <div class="flex items-center justify-center gap-3">
                                        <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="text-blue-600 hover:text-blue-700 transition">
                                            <i class="fas fa-edit text-xl"></i>
                                        </a>
                                        <form id="deleteForm" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>

                                        <!-- Tombol Delete -->
                                        <a href="#" 
                                        onclick="confirmDelete(<?php echo e($project->id); ?>)" 
                                        class="text-red-600 hover:text-red-700 transition">
                                            <i class="fas fa-trash text-xl"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                                    Belum ada data Project.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>        
            <?php if($projects->hasPages()): ?>
                <div class="bg-white px-6 py-4 border-t border-gray-200">
                    <?php echo e($projects->links()); ?>

                </div>
            <?php endif; ?>
            
        </div>
    </div>

    <script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Yakin ingin menghapus?',
            text: "Data project ini dan semua task di dalamnya akan terhapus permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                const form = document.getElementById('deleteForm');
                form.action = `/projects/${id}`;   // Laravel resource route otomatis pakai DELETE
                form.submit();

                Swal.fire({
                    title: 'Menghapus...',
                    text: 'Mohon tunggu sebentar',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    willOpen: () => {
                        Swal.showLoading();
                    }
                });
            }
        });
    }
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Projects\Laravel\TaskManagement\resources\views/pages/projects/index.blade.php ENDPATH**/ ?>