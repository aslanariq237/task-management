
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<a <?php echo e($attributes->merge([
    'class' => '
        flex items-center gap-3 px-4 py-3.5 text-[15px] font-medium rounded-2xl 
        transition-all duration-200
        ' . ($active 
            ? 'bg-blue-600 text-white shadow-md hover:bg-blue-700' 
            : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
        )
    ])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH D:\Projects\Laravel\TaskManagement\resources\views/components/nav-link.blade.php ENDPATH**/ ?>